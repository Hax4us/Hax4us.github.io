#ifndef OUT_TCP_SERVICES_H
#define OUT_TCP_SERVICES_H

const char *tcp_service_name(int port);
const char *udp_service_name(int port);
const char *oproto_service_name(int protocol_number);

#endif

